import {NextResponse} from 'next/server';
export async function POST(req:Request){
 const body=await req.json();
 // Production hook: call your selected video provider here, then queue the job
 // for a server-side renderer (FFmpeg) and return a job id.
 return NextResponse.json({ok:true,jobId:`demo_${Date.now()}`,message:`Demo job created for ${body.mode==='audio'?'audio':'text'} → video. Add VIDEO_API_KEY to enable real generation.`});
}
