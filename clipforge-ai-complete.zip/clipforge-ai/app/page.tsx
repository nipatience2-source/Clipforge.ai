'use client';
import {useState} from 'react';

const presets=['Cinematic','Kids / Nursery','YouTube','TikTok / Reels','Product ad'];

export default function Home(){
 const [mode,setMode]=useState<'text'|'audio'>('text');
 const [prompt,setPrompt]=useState('A cheerful animated classroom where friendly children clap, sing and learn numbers.');
 const [duration,setDuration]=useState(60);
 const [preset,setPreset]=useState('Kids / Nursery');
 const [status,setStatus]=useState('Ready');
 const [file,setFile]=useState<File|null>(null);
 const generate=async()=>{
   setStatus('Preparing generation…');
   try{
    const r=await fetch('/api/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode,prompt,duration,preset,fileName:file?.name})});
    const d=await r.json(); setStatus(d.message||'Job created');
   }catch{setStatus('Demo mode: connect a video provider API to generate real clips.');}
 };
 return <main>
  <header><div className="logo">✦ ClipForge <span>AI</span></div><button className="ghost">Sign in</button></header>
  <section className="hero"><div><p className="eyebrow">AI VIDEO STUDIO</p><h1>Turn an idea or song into a video.</h1><p className="sub">Create up to 5-minute projects with AI scenes, captions, music and an editor-ready timeline.</p></div></section>
  <section className="workspace">
   <aside className="panel">
    <h2>Create</h2>
    <div className="tabs"><button className={mode==='text'?'active':''} onClick={()=>setMode('text')}>Text → Video</button><button className={mode==='audio'?'active':''} onClick={()=>setMode('audio')}>Audio → Video</button></div>
    {mode==='text'?<textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Describe your video…"/>:<label className="upload">🎵<b>{file?file.name:'Upload a song or voice recording'}</b><input type="file" accept="audio/*" onChange={e=>setFile(e.target.files?.[0]||null)}/></label>}
    <label>Style<select value={preset} onChange={e=>setPreset(e.target.value)}>{presets.map(x=><option key={x}>{x}</option>)}</select></label>
    <label>Length <strong>{duration>=300?'5:00':`${Math.floor(duration/60)}:${String(duration%60).padStart(2,'0')}`}</strong><input type="range" min="15" max="300" step="15" value={duration} onChange={e=>setDuration(+e.target.value)}/></label>
    <button className="generate" onClick={generate}>Generate video ✨</button><p className="status">{status}</p>
   </aside>
   <section className="editor">
    <div className="preview"><div className="play">▶</div><p>Preview</p><small>Your generated scenes will appear here.</small></div>
    <div className="toolbar"><button>＋ Scene</button><button>Text</button><button>🎵 Audio</button><button>CC Captions</button><button>Transition</button><button>Export MP4</button></div>
    <div className="timeline"><div className="track-title">VIDEO</div><div className="clip c1">Scene 1</div><div className="clip c2">Scene 2</div><div className="clip c3">Scene 3</div></div>
    <div className="timeline"><div className="track-title">AUDIO</div><div className="audio">Voice / music track</div></div>
   </section>
  </section>
  <section className="features"><div><b>5 min</b><span>Project length</span></div><div><b>9:16</b><span>Shorts & Reels</span></div><div><b>16:9</b><span>YouTube</span></div><div><b>AI</b><span>Scene generation</span></div></section>
  <footer>ClipForge AI • Starter build • Connect a video-generation API and a rendering backend before production.</footer>
 </main>
}
